const express = require('express');
const morgan  = require('morgan');
const bodyParser = require('body-parser');
const app =  express();
const mongoose = require('mongoose');

mongoose.set('useCreateIndex', true)
mongoose.connect('mongodb://localhost/node',{ useNewUrlParser: true });

//Middlewares
app.use(morgan('dev'));
app.use(bodyParser.json());

//Routers
app.use('/user', require('./app/routes/user.route'));
app.use('/customer', require('./app/routes/customer.route'));
app.use('/task', require('./app/routes/task.route'));

const port = process.env.PORT || 3000;

app.listen(port);
console.log(`Server Listening port ${port}`);

//2017-08-10 13:12:16